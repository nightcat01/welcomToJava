# jforum2
JForum 2.x series

JForum was a bulletin board software based on PHPBB which I wrote back in the 2000's. It was my first big open source project, and I worked on it for several years. There are still code from my early Java days, and you can still see the tradicional MVC implementation. 

In the gold Java years it was used by some big sites, like JavaRanch.com, GUJ.com.br (biggest java community in Brazil) and Sony Online Entertainment. 

I have ceased development and maintenance for several years already, and I only keep the code (and the website, jforum.net) alive for historial reasons. I do not intend to apply fixes or develop new features. 

Keep in mind that this a very old codebase, and I have since evolved a lot as professional developer. 
